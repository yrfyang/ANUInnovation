package com.example.renfeiyang.myapplication1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by renfeiyang on 17/3/18.
 */

public class InfoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.setContentView(R.layout.activity_info);

        super.onCreate(savedInstanceState);

    }
}
